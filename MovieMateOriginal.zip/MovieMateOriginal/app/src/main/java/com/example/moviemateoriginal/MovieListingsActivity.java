package com.example.moviemateoriginal;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MovieListingsActivity extends AppCompatActivity {
    private GridView gridView;
    private MovieAdapter movieAdapter;
    private Spinner filterSpinner;

    // Sample movie titles and posters - replace with your own data
    private String[] movieTitles = {"Wish", "Lost Tiger", "Strange World", "Inside Out", "Over The Moon"};
    private int[] moviePosters = {
            R.drawable.movie1_poster, // Replace with actual image resources
            R.drawable.movie2_poster,
            R.drawable.movie3_poster,
            R.drawable.movie4_poster,
            R.drawable.movie5_poster
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_listings);

        gridView = findViewById(R.id.movie_grid);
        filterSpinner = findViewById(R.id.filter_spinner);

        // Set up the GridView with the MovieAdapter
        movieAdapter = new MovieAdapter(this, movieTitles, moviePosters);
        gridView.setAdapter(movieAdapter);

        // Set up filter options for the Spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.movie_filters, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        filterSpinner.setAdapter(adapter);
    }

    BottomNavigationView bottomNav = findViewById(R.id.bottom_nav);
bottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(MenuItem item) {
            switch (item.getItemId()) {
                case R.id.nav_profile:
                    startActivity(new Intent(MovieListingsActivity.this, ProfileActivity.class));
                    return true;
                case R.id.nav_settings:
                    startActivity(new Intent(MovieListingsActivity.this, SettingsActivity.class));
                    return true;
                case R.id.nav_history:
                    startActivity(new Intent(MovieListingsActivity.this, HistoryActivity.class));
                    return true;
                default:
                    return false;
            }
        }
    });


}
